<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе
 * установки. Необязательно использовать веб-интерфейс, можно
 * скопировать файл в "wp-config.php" и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки MySQL
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define( 'DB_NAME', 'statusquo' );

/** Имя пользователя MySQL */
define( 'DB_USER', 'root' );

/** Пароль к базе данных MySQL */
define( 'DB_PASSWORD', '' );

/** Имя сервера MySQL */
define( 'DB_HOST', 'localhost' );

/** Кодировка базы данных для создания таблиц. */
define( 'DB_CHARSET', 'utf8mb4' );

/** Схема сопоставления. Не меняйте, если не уверены. */
define( 'DB_COLLATE', '' );

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '//K)|2uJpjp>ULs{1R@:8m17e8sVhBJf[t5.CI]t8pwY^m<Cd/m-*.9/)lkk nfr' );
define( 'SECURE_AUTH_KEY',  'Dh__&zmV*Vdgfb:V`qnGAo{e]~?o/ql]%FULb,$NezA%&R|N[cAwmW,3gh.Wfknf' );
define( 'LOGGED_IN_KEY',    '}Fg`!gSTN1kS#A6LZma=f[<+bn#q$:Ez7eitJW tYwrZnDC%T6s&&;yQnj@v1H=l' );
define( 'NONCE_KEY',        'WY:Oj|/espm=I>-@qA0<N$lR.+I QGU%S8m)KV53S}LX8DpM3rs420xm^xg n~ZJ' );
define( 'AUTH_SALT',        'gZ&T:8OJ0[]N.T>OwvXAxdnWH,JoG,w/~7:BP:0cmlc3_OhX3roFrdj6xAFvruEI' );
define( 'SECURE_AUTH_SALT', '4}F[Kzo0RJb:Kx72P9}4Y~NOyX?&;P|{wv/^F[5Vo~ClQ)3K/)f*`}e?5Ru&B&j`' );
define( 'LOGGED_IN_SALT',   '/ydB1Y!2tlJn2 zUz&fwo%r` U.+L=W/mM2?@Lt,keB;nrF:/O>Kq}qn4JagmhbW' );
define( 'NONCE_SALT',       'zF?W86$r4JmiZ~+J!:| ZA>hA]S`ny,!-J {bdh*Pwb![t]io]8gRAN63vhg]#}a' );

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в Кодексе.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Инициализирует переменные WordPress и подключает файлы. */
require_once( ABSPATH . 'wp-settings.php' );
